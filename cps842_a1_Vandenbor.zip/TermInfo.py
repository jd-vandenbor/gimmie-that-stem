class TermInfo:
    def __init__(self, term, frequency, positions=[]):
        self.term = term
        self.frequency = frequency
        self.positions = positions
